In het mapje zijn de volgende bestanden opgenomen:
- lvbb, stop en xsd bevatten de xmlschema's

- De voorbeeldbestanden zitten in de directory opdracht.