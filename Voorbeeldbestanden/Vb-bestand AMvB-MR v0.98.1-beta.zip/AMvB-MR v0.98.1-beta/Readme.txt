﻿In het mapje zijn de volgende bestanden opgenomen:
- IMOP bevat de OP-bestanden voor de LVBB.
- IMOW bevat de OW-bestanden voor OZON.
- Opdracht bevat alle bestanden, zoals die aangeleverd kunnen worden aan de LVBB.
- Word bevat de oorspronkelijke Word-bestanden.
- Annotaties.docx geeft een overzicht van alle annotaties in het voorbeeldbestand.

Opmerking 1: AMvB's zullen normaliter, in productie, géén GIO's zullen bevatten. GIO's die er nu in voorkomen, zijn alleen opgenomen voor testdoeleinden van de basisfunctionaliteit van de keten. Normaliter zullen de GIO's die horen bij juridische regels van AMvB's in de Mr/Or voorkomen.

Opmerking 2: Dit voorbeeld is op basis van IMOW versie 0.98.1-beta