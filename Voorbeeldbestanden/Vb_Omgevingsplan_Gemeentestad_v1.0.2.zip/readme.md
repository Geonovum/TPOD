De 1.0.2-versie van Gemeentestad is gebaseerd op de IMOW-schema's v1.0.2 en STOP-schema's v1.0.3.

De wijzigingen in Gemeentestad zijn gedaan o.b.v. reviewopmerkingen vanuit de LVBB en Kadaster om te zorgen dat dit voorbeeldbestand zichtbaar is in de DSO-LV-viewer en in de registratie toepasbare regels.