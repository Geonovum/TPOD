# Voorbeeldbestand Instructie v1.0.0

Voorbeeldbestand instructie v1.0.0 is gebaseerd op de IMOW-schema's v1.0.2 en STOP-schema's v1.0.3.

Dit voorbeeldbestand is succesvol door de DSO-keten verwerkt. Het bestand is gebaseerd op STOP-versie 1.0.3 en IMOW-versie 1.0.2.
