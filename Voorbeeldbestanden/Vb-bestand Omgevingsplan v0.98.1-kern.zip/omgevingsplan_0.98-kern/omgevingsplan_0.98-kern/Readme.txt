﻿In het mapje zijn de volgende bestanden opgenomen:
- IMOP bevat de OP-bestanden voor de LVBB.
- IMOW bevat de OW-bestanden voor OZON.

Opmerking 1: Het voorbeeldbestand voor IMOP/BesluitInitieleRegeling-bsl2-Gemeentestad.xml zal inconsistenties bevatten. Het is toegevoegd ter ondersteuning van de bestanden in map IMOW. De schemaverwijzing verwijst in het voorbeeldbestand naar een lokale versie van de schema's. De laatste versies vindt u op https://koop.gitlab.io/STOP/standaard.

Opmerking 2: Dit voorbeeld is op basis van IMOW versie 0.98-kern en IMOP versie 0.98-kern.