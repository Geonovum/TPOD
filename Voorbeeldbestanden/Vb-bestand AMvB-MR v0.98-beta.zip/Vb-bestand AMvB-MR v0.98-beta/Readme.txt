In het mapje zijn de volgende bestanden opgenomen:
- IMOP bevat de OP-bestanden voor de LVBB.
- IMOW bevat de OW-bestanden voor OZON.
- xsd bevat de bestanden bij IMOW versie 0.98-beta.
- Opdracht bevat alle bestanden, zoals die aangeleverd kunnen worden aan de LVBB.
- Word bevat de oorspronkelijke Word-bestanden.
- Annotaties.docx geeft een overzicht van alle annotaties in het voorbeeldbestand.
