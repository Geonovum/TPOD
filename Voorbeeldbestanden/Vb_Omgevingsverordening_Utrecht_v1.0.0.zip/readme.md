Voorbeeldbestand omgevingsverordening Utrecht v1.0.0 is gebaseerd op de IMOW-schema's v1.0.2 en STOP-schema's v1.0.3.

Het voorbeeld van provincie Utrecht is succesvol door de keten gehaald.