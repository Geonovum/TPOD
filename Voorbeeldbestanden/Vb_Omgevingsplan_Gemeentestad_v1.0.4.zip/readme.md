Voorbeeldbestand omgevingsplan Gemeentestad v1.0.4 is gebaseerd op de IMOW-schema's v1.0.2 en STOP-schema's v1.0.3.

Het Gemeentestad-voorbeeld is door de keten gehaald, dat was het vorige voorbeeld ook, maar bij deze is de verwerking in de Functionele Structuur beter gestructureerd (met een topactiviteit).
