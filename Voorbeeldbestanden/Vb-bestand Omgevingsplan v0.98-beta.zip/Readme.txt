In het mapje zijn de volgende bestanden opgenomen:
- IMOP bevat de OP-bestanden voor de LVBB.
- IMOW bevat de OW-bestanden voor OZON.
- xsd bevat de bestanden bij IMOW versie 0.98-beta.
- Opdracht bevat alle bestanden, zoals die aangeleverd kunnen worden aan de LVBB.

Opmerking bij IMOW owActiviteiten-Gemeentestad.xml. Dit bestand bevat activiteiten waarvan de bovenliggende activiteit afkomstig zijn uit de Functionele Structuur Versie 9.