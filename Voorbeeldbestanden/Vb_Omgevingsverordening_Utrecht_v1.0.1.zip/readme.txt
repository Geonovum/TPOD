Het voorbeeld Omgevingsverordening Utrecht, dat ook gebruikt is voor de eerstekamerdemo. 
Dit bestand is omgezet naar STOPv1.0.4.
De variant die specifiek bedoeld is voor de ontwerpversie incl. kennisgeving volgt nog.