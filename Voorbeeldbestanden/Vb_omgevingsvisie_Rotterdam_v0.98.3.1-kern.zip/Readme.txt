﻿In het mapje 'opdracht' zijn alle bestanden voor aanlevering aan de LVBB opgenomen.

Opmerking 1: De schemaverwijzingen in de voorbeeldbestanden verwijzen naar een lokale versie van de schema's. De laatste versies vindt u op https://koop.gitlab.io/STOP/standaard (IMOP versie 0.98-kern) en https://github.com/Geonovum/TPOD/tree/master/CIMOW (IMOW versie 0.98.1-kern).

Opmerking 2: De volgende punten worden in IMOP verder uitgewerkt:
- De manier van verwijzen naar GIO's, zowel naar alle geometrieën in een featurecollection als naar geometrieën in onderliggende featuremembers.
- De manier waarop nieuwe waarden toegevoegd kunnen worden aan open waardelijsten. 
- De manier waarop in de vrijetekststructuur FormeleDivisie en FormeleInhoud wordt gebruikt.

Opmerking 3: De volgende punten worden in IMOW verder uitgewerkt:
- De manier van verwijzen naar GIO's, zowel naar alle geometrieën in een featurecollection als naar geometrieën in onderliggende featuremembers.
- De manier waarop verwezen kan worden naar geometrieën die in IMOP geen GIO's zijn.
- De manier waarop verwezen wordt naar waarden in waardelijsten.
- De manier waarop in de vrijetekststructuur naar FormeleDivisie en FormeleInhoud wordt verwezen.
