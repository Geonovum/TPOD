# Transformatie 0.98.3-kern naar 1.0
De transformatie bestaat uit een ant-buildscript en de benodigde xslt's.
## Installatie met Oxygen
De transformatie kan met Oxygen worden uitgevoerd. Hiervoor is een extra library nodig, die niet standaard door Oxygen wordt geïmplementeerd. Dat is de bijgevoegde xmltask.jar. Deze komt in de map '[Programmamap Oxygen]\tools\ant\lib'.
Voor de verwerking van geometrieën is veel geheugenruimte nodig. Daarom is het soms nodig om in het ANT-transformatiescenario de geheugenruimte voor Java uit te breiden. Bij JVM-argumenten komt de tekst '-Xmx1024m' te staan.
## Verwerking
De transformatie bestaat uit vier verschillende onderdelen:
- transformatie OP
- transformatie OW
- transformatie GIO
- transformatie GML
## Disclaimer
Het bijgevoegde script gebruiken wij binnen Geonovum om content om te zetten van een 0.98.3-versie naar de 1.0-versie van de standaard. Dit script mag vrijelijk gebruikt worden door eenieder die daar baat bij heeft. Daarbij willen we wel graag het volgende duidelijk maken. Geonovum is geen softwareontwikkelaar en heeft dit script ook niet als zodanig ontwikkeld. Dat betekent dat gebruik voor eigen nut van harte wordt aangemoedigd, maar dat wij daar maar beperkte ondersteuning op bieden in toelichting en gebruik. Als het script in de eigen omgeving niet werkt of niet werkend kan worden gemaakt, is dat de verantwoordelijkheid van de gebruiker. Verzoeken voor ondersteuning kunnen worden ingediend via de helpdesk, omgevingswet@geonovum.nl. Mocht er content omgezet moeten worden naar 1.0 zonder de mogelijkheid gebruik te maken van het script, laat ons dat dan weten.