# Omgevingsplan_HelloDSO_0.98.3-kern

Deze casus is het eenvoudigste technische en inhoudelijke voorbeeld van een compleet model waarmee een gemeente: aansluit op de bekendmaking van een omgevingswetbesluit door LVBB en gebruik maakt van de dienstverlening van het DSO-LV.