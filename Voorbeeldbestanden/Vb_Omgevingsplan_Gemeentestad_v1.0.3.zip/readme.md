De 1.0.3-versie van voorbeeldbestand omgevingsplan Gemeentestad is gebaseerd op de IMOW-schema's v1.0.2 en STOP-schema's v1.0.3.
Technisch en inhoudelijk is deze versie gelijk aan v1.0.2. Wegens onduidelijkheid over de versienummers in de keten is deze versie v1.0.3 uitgebracht.

De wijzigingen in Gemeentestad zijn gedaan o.b.v. reviewopmerkingen vanuit de LVBB en Kadaster om te zorgen dat dit voorbeeldbestand zichtbaar is in de DSO-LV-viewer en in de registratie toepasbare regels.