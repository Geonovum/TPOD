
Dit schema is samengesteld door Kadaster tbv. aansluiting bij NEN3610-2011.

Zie voor meer informatie over IMKAD als sectormodel van NEN3610: 
http://www.kadaster.nl/window.html?inhoud=/schemas/

NEN3610 is een standaard vastgesteld door Geonovum: 
http://www.geonovum.nl/

Zie voor NEN3610: 
http://www.geonovum.nl/geostandaarden/nen3610

