# xml_waterschapsverordening_limburg_1.0
Waterschapsverordening Limburg is gebaseerd op de IMOW-schema's v1.0.2 en STOP-schema's v1.0.3.


