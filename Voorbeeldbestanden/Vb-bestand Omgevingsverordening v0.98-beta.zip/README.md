# Map bestemd voor bestanden voor de praktijkproef Omgevingsverordening Gelderland

1- versie 0.98-beta heeft twee deel: OP en OW.
2- OP bevat:manifest.xml, opdracht.xml,akn_nl_Omgevingsordening_pv25_2019-01-01.xml, Boringvrijzone.gml, Extensiveringsgebied_glastuinbouw.gml, 
grondbeschermeingsgebieden.gml, Grote_Rivieren.gml, Nieuwe_Hollandse_Waterline.gml, Provencie_Gelderland.gml, 
Tijdelijke_verbod_nieuwestiging_glastuinbouw.gml en Waterverbinder.gml
3- OW bevat manifets-ow.xml, owRegeltekst, owActivteit.xml en owLocaties.
4- xsd directory bevat xsd's die gebruikt wordt voor vesie 0.98-beta
5- Mappingdirecory bevat een paar xsd's voor validatie 

