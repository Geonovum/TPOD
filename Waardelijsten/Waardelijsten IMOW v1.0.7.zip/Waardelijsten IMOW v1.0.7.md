# Waardelijsten v1.0.7
De volgende wijzigingen zijn in Waardelijsten v1.0.7 doorgevoerd:
- De waarde 'cultureel erfgoed en landschap – cultureel erfgoed' heeft Toelichting: 'Deze waarde kan gebruikt worden'. Dat moet gewijzigd worden in 'Deze waarde niet gebruiken.'
- De waarde 'cultureel erfgoed' moet worden toegevoegd, met Toelichting: 'Deze waarde kan gebruikt worden'.
- De waarde 'veiligheid – externe veiligheid' heeft Toelichting: 'Deze waarde kan gebruikt worden'. Dat moet gewijzigd worden in 'Deze waarde niet gebruiken.'
- De waarde 'externe veiligheid' moet worden toegevoegd, met in de kolom Toelichting: Deze waarde kan gebruikt worden. Hiervoor moet domein 'externe veiligheid' toegevoegd worden.