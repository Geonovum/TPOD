# Waardelijsten v1.0.9
De volgende wijzigingen zijn in Waardelijsten v1.0.9 doorgevoerd:
- Van waardelijst 'eenheid' is de omschrijving gewijzigd.
- Bij waardelijst 'eenheid' is waarde 'aantal' toegevoegd.
- Bij waardelijst 'type norm' is waarde 'welstandsniveau' toegevoegd.