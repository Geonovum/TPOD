# Waardelijsten IMOW v1.0.8
De volgende wijzigingen zijn in Waardelijsten IMOW v1.0.8 doorgevoerd:
- Van waardelijst 'thema' is bij waarde 'cultureel erfgoed' de definitie toegevoegd.
- Van waardelijst 'thema' is bij waarde 'externe veiligheid' de definitie toegevoegd.
- Bij waardelijst 'activiteitengroep' is waarde 'landinrichtingsactiviteit' toegevoegd.
- Bij waardelijst 'activiteitengroep' is waarde 'toegangsactiviteit' toegevoegd.
- Bij waardelijst 'eenheid' is waarde 'nog toe te voegen' toegevoegd.
- Bij waardelijst 'type norm' is waarde 'nog toe te voegen' toegevoegd.
- Bij waardelijst 'natuurgroep' is waarde 'habitatrichtlijngebied' toegevoegd.
- Bij waardelijst 'natuurgroep' is waarde 'vogelrichtlijngebied' toegevoegd.
- Bij waardelijst 'natuurgroep' is waarde 'toegangsbeperkingsgebied' toegevoegd.
- Bij waardelijst 'externe veiligheidgroep', waarde 'maatregelengebied' is het domein aangepast.
- Bij waardelijst 'ruimtelijk gebruikgroep', waarde 'maatregelengebied' is het domein aangepast.
- Bij waardelijst 'water en watersysteemgroep', waarde 'maatregelengebied' is het domein aangepast.