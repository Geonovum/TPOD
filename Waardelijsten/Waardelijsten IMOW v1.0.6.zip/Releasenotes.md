# Waardelijsten v1.0.6
De volgende wijzigingen zijn doorgevoerd:
- Waarden en domeinen van waardelijst Thema zijn aangepast conform WELT 112.
- Bij eenheid Bouwlaag is achtervoegsel '(hoogte)' verwijderd.
- Onjuiste toelichting in de domeinen van waardelijst Thema verwijderd.