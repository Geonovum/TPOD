# Omgevingswaarderegel

**Omgevingswaarderegel** is één van de drie typen van [Juridische regel](#begrip-juridische-regel) die in een omgevingsdocument met [Artikelstructuur](#begrip-artikelstructuur)
voor kan komen. Het is een regel over een [omgevingswaarde](#begrip-omgevingswaarde) als bedoeld in afdeling 2.3 Omgevingswet, die op zichzelf alleen gericht is tot de bestuursorganen 
van het bevoegd gezag dat de omgevingswaarde heeft vastgesteld.

*bron: TPOD*
