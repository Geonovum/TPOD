# Naamgevingsconventie

**Naamgevingsconventie** is een gestandariseerde manier om documenten, delen van documenten of objecten te identificeren.

*bron: STOP*
