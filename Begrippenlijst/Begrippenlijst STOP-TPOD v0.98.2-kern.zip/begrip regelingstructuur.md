# Regelingstructuur

De **regelingstructuur** is de documentstructuur volgens welke een formele regeling wordt opgebouwd en regelt dat de componenten RegelingOpschrift,
Aanhef, Lichaam en Sluiting aanwezig zijn.

*bron: STOP*
