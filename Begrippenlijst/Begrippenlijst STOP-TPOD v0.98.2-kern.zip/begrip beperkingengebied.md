# Beperkingengebied

Een **beperkingengebied** is een bij of krachtens de Omgevingswet aangewezen gebied waar vanwege de aanwezigheid van een werk of object regels gelden over
[activiteiten](#begrip-activiteit) die gevolgen hebben of kunnen hebben voor dat werk of object.

Het is één van de [annotaties](#begrip-annotatie-annoteren) in DSO.

*bron: TPOD*
