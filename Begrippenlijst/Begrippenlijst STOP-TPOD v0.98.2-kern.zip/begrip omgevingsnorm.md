# Omgevingsnorm

Een **omgevingsnorm** is het objecttype voor omgevingsdocumenten met Artikelstructuur(#begrip-artikelstructuur) dat machineleesbaar maakt dat een 
Juridische regel(#begrip-juridische regel) en de bijbehorende Locatie(s) gaan over een [norm] over de fysieke leefomgeving die in een kwantitatieve of kwalitatieve waarde wordt 
uitgedrukt en geen omgevingswaarde is.

*bron: TPOD*
