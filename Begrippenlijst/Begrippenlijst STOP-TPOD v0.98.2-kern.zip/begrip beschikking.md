# Beschikking

Een **beschikking**, als bedoeld in artikel 1:3 lid 2 van de Algemene wet bestuursrecht, is een [besluit](#begrip-besluit) dat niet van algemene 
strekkking is, met inbegrip van de afwijzing van een aanvraag daarvan.

*bron: Awb*

