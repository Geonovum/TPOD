# Besluit

Een **besluit**, als bedoeld in artikel 1:3 lid 1 van de Algemene wet bestuursrecht, is een schriftelijke beslissing van een bestuursorgaan,
inhoudende een publiekrechtelijke rechtshandeling.

*bron: Awb*

