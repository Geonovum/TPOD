# Regel voor iedereen

**Regel voor iedereen** is één van de drie typen van [Juridische regel](#begrip-juridische-regel) die in een omgevingsdocument met [Artikelstructuur](#begrip-artikelstructuur)
voor kunnen komen. Het is een regel die voor eenieder relevant is of relevant kan zijn en geen [Instructieregel](#begrip-instructieregel) of [Omgevingswaarderegel](#begrip-omgevingswaarderegel) is.

*bron: TPOD*
