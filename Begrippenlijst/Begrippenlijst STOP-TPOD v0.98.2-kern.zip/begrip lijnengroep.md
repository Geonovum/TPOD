# Lijnengroep

**Lijnengroep** is een groep of verzameling van bij elkaar behorende [Lijnen](#begrip-lijn), die samen de [Locatie](#begrip-locatie) vormen. 
Lijnengroep is één van de verschijningsvormen van Locatie.

*bron: TPOD*
