# Vrijetekststructuur

**Vrijetekststructuur** is de [tekststructuur](#begrip-tekststructuur) die wordt gebruikt voor die onderdelen van (formele)[regelingen](#begrip-regeling)
die geen artikelen bevatten.

*bron: STOP en TPOD*
