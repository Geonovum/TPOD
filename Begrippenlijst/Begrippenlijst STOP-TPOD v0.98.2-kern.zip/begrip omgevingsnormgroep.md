# Omgevingsnormgroep

**Omgevingsnormgroep** is de categorie waartoe de [Omgevingsnorm](#begrip-omgevingsnorm) behoort. 
Voor Omgevingsnormgroep bestaat een [limitatieve waardelijst](#begrip-limitatieve-waardelijst) 'Omgevingsnormgroep'. 

*bron: TPOD*
