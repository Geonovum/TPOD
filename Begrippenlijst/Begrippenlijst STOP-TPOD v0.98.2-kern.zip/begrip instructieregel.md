# Instructieregel

**Instructieregel** is één van de drie typen van [Juridische regel](#begrip-juridische-regel) die in een omgevingsdocument met [Artikelstructuur](#begrip-artikelstructuur) 
voor kan komen. Het is een regel als bedoeld in paragraaf 2.5.1 Omgevingswet, gericht tot een ander bestuursorgaan of bestuurlijke organisatie.

*bron: TPOD*
