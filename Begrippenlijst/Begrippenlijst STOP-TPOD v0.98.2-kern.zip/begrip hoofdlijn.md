# Hoofdlijn

**Hoofdlijn** is een element dat de hoofdlijn weergeeft van het beleid voor of de kwaliteit, ontwikkeling of staat van de fysieke leefomgeving dat of die 
in het [Tekstdeel](#begrip-tekstdeel) wordt beschreven.

*bron: TPOD*
