# Tekststructuur

De **tekststructuur** is de, al dan niet hiërarchische, ordening van de tekstblokken die tezamen de tekstuele inhoud van de bekendmaking vormen. 
IMOP kent twee soorten tekststructuur: [Artikelstructuur](#begrip-artikelstructuur) voor regelingen met artikelen en [Vrijetekststructuur](#begrip-vrijetekststructuur) 
voor regelingen zonder artikelen.

*bron: STOP*
