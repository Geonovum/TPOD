# Vervanging

Een **vervanging** is een soort [mutatie](#begrip-muteren) welke leidt tot een wijziging van een tekst of [regeling](#begrip-regeling). Deze bestaat uit
de specificatie van een geheel nieuwe versie van de component, waarbij de vorige versie komt te vervallen, ongeacht hoe die vorige versie luidde.

*bron: STOP*
