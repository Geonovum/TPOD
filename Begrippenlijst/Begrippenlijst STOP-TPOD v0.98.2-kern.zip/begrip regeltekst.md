# Regeltekst

Een **regeltekst** is de kleinste zelfstandige eenheid van (een of meer) bij elkaar horende [Juridische regels](#begrip-juridische-regel) in 
die onderdelen van omgevingsdocumenten die de [Artikelstructuur](#begrip-artikelstructuur) hebben, te weten een artikel of een lid.

*bron: TPOD*
