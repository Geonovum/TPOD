# Thema

**Thema** is een attribuut van [Juridische regel](#begrip-juridische-regel) en [Tekstdeel](#begrip-tekstdeel) dat kernachtig de grondgedachte van de tekst weergeeft. 
Vaak is het een aanduiding van het sectorale aspect waar het Tekstdeel over gaat. Voor Thema bestaat een [uitbreidbare waardelijst](#begrip-uitbreidbare-waardelijst) ‘Thema’.

*bron: STOP en TPOD*
