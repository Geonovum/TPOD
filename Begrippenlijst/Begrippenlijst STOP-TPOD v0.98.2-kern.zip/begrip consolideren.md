# Consolideren

**Consolideren** is het correct verwerken van de wijzigingen qua geldigheid op een [initieel besluit](#begrip-initieel-besluit)
na zijn inwerkingtreding, op basis van de wijzigingsinstructies die in navolgende [besluiten](#begrip-besluit) zijn bekendgemaakt.
Het proces van consolidatie is in het leven geroepen om uit de bekendgemaakte en in werking zijnde besluiten af te leiden wat op elk moment 
in de tijd de geldende regelgeving is.

*bron: STOP*
