# Functiegroep

**Functiegroep** is de categorie waartoe de [functie](#begrip-functie) behoort. Voor functiegroep bestaat een [limitatieve waardelijst](#begrip-limitatieve-waardelijst) 'Functiegroep'.

*bron: TPOD*
