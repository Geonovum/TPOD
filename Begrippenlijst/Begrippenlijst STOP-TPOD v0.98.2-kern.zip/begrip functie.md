# Functie

Een **functie** is het gebruiksdoel of de bijzondere eigenschap die een onderdeel van de fysieke leefomgeving op een bepaalde [locatie](#begrip-locatie) heeft. Het is één
van de [annotaties](#begrip-annotatie-annoteren) die vallen onder een [gebiedsaanwijzing](#begrip-gebiedsaanwijzing).
Functie is beschikbaar voor omgevingsplan en omgevingsverordening, dat machineleesbaar maakt dat een Juridische regel of een beleidstekst en 
de bijbehorende Locatie(s) een gebied aanwijzen van het type Functie, waarmee de betreffende functie op een bepaalde locatie wordt vastgelegd. 

*bron: TPOD*
