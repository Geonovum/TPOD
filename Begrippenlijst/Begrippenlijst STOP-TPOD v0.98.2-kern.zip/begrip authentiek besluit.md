# Authentiek besluit

Het **authentieke besluit** is de term die door juristen wordt gebruikt om de vastlegging van de beslissing aan te duiden die in het besluitvormingsproces
door het bevoegd gezag is vastgesteld.

*bron: STOP*

