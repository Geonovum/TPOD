# Omgevingswaardegroep

**Omgevingswaardegroep** is de categorie waartoe de [Omgevingswaarde](#begrip-omgevingswaarde) behoort. 
Voor Omgevingswaardegroep bestaat een [limitatieve waardelijst](#begrip-limitatieve-waardelijst) 'Omgevingswaardegroep'. 

*bron: TPOD*
