# Normwaarde

attribuut waarmee kan worden vastgelegd welke waarde een omgevingswaarde op een bepaalde locatie heeft. normwaarde kan kwantitatief (oftewel numeriek) of kwalitatief (oftewel in woorden) worden uitgedrukt of in de Regeltekst worden opgenomen.

**Normwaarde** is het attribuut waarmee kan worden vastgelegd welke waarde een [omgevingsnorm](#begrip-omgevingsnorm) of [omgevingswaarde](#begrip-omgevingswaarde) op een bepaalde [Locatie](#begrip-locatie) heeft. Normwaarde kan kwantitatief (oftewel numeriek) of kwalitatief (oftewel in woorden) worden uitgedrukt. 

*bron: TPOD*
