# Werkingsgebied

Het **werkingsgebied** is een abstract, conceptueel begrip: het gebied waar een [Regeltekst](#begrip-regeltekst) of [Divisie](#begrip-divisie) 
zijn werking heeft. Het begrip werkingsgebied wordt in de STOP-standaard gebruikt voor de computerleesbare verbinding tussen een regeltekst en 
de GIO's.

*bron: TPOD en STOP*
