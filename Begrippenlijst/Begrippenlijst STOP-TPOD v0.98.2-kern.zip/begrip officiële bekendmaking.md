# Officiële bekendmaking

De **officiële bekendmaking** is de bekendmaking van de (wijzigingen in) wet- en regelgeving en verdragen van de centrale overheid, maar ook (wijzigings)besluiten
van decentrale overheden die door de bij wet verplichte officiële bekendmaking hun rechtsgeldigheid verwerven. De officiële bekendmaking wordt gepubliceerd in een 
voor betreffend soort [besluit](#begrip-besluit) bij wet aangewezen publicatieblad.

*bron: STOP*
