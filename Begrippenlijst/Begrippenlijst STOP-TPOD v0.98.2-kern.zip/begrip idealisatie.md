# Idealisatie

**Idealisatie** is het attribuut dat vastlegt op welke manier de begrenzing van [Locatie](#begrip-locatie) voor de bijbehorende [Juridische regel](#begrip-juridische-regel) 
geïnterpreteerd moet worden en door het bevoegd gezag bedoeld is. Voor Idealisatie geldt een [limititatieve waardelijst](#begrip-limititatieve-waardelijst) 'Idealisatie'.

*bron: TPOD*
