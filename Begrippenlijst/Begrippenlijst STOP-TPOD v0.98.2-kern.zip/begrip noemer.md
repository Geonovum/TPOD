# Noemer

De **Noemer** is de mensleesbare naam of frase waarmee de [Locatie](#begrip-locatie) wordt aangeduid. Uit de tekst van [Juridische regel](#begrip-juridische-regel) of 
[Tekstdeel](#begrip-tekstdeel) moet duidelijk blijken welke Locatie er bij hoort. Daarom wordt in de tekst deze verwijzing naar de locatie opgenomen.
Hierdoor is het duidelijk dat Locatie en Juridische regel respectievelijk Tekstdeel bij elkaar horen. Diezelfde noemer wordt in de locatie vastgelegd.

*bron: TPOD*
