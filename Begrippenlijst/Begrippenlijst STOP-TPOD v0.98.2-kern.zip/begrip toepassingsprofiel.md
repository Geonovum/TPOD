# Toepassingsprofiel

Het **toepassingsprofiel** bevat domeinspecifieke afspraken(hier voor de Omgevingswet) voor officiële overheidspublicaties. 
Het is een nadere invulling c.q. beperking van de algemene Standaard voor officiële publicaties (STOP). De toepassingsprofielen 
geven voor het specifieke domein aan welke specifieke regels er gelden t.a.v. inhoud en metadata (eigenschappen en
[waardelijsten](#begrip-waardelijst)). Voor de Omgevingswet is het Toepassingsprofiel omgevingsdocumenten (TPOD) van toepassing 
en er is voor elk soort omgevingsdocument een apart toepassingsprofiel, bijvoorbeeld toepassingsprofiel omgevingsplan,
toepassingsprofiel projectbesluit, toepassingsprofiel waterschapsverordening, etc.

*bron: STOP*
