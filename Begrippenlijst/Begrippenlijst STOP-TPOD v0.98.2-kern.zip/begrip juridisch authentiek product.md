# Juridisch authentiek product

Een **juridisch authentiek product** is een productwaarvan de inhoud via een juridisch voorgeschreven procedure door een overheid vastgesteld en gepubliceerd
wordt.

*bron: STOP*
