# Bronhouderskoppelvlak

Het **bronhouderskoppelvlak** is een technische voorziening tussen de LVBB (Landelijke Voorziening Bekendmaken en Beschikbaar stellen) en (software van) 
een bevoegd gezag. In dat koppelvlak worden technische en inhoudelijke standaarden toegepast, waardoor inhoudelijke, proces- of foutinformatie tussen de 
systemen kan worden uitgewisseld.

*bron: STOP*