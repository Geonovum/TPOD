# Puntengroep

**Puntengroep** is een groep of verzameling van bij elkaar behorende [Punten](#begrip-punt), die samen de [Locatie](#begrip-locatie) vormen. 
Puntengroep is één van de verschijningsvormen van Locatie.

*bron: TPOD*
