# Locatieaanduiding

Een **locatieaanduiding** is de verwijzing van een specifieke [Juridische regel](#begrip-juridische-regel), [Tekstdeel](#begrip-tekstdeel), [Activiteit](#begrip-activiteit), 
[Omgevingsnorm](#begrip-omgevingsnorm), [Omgevingswaarde](#begrip-omgevingswaarde) of type [Gebiedsaanwijzing](#begrip-gebiedsaanwijzing) naar (de identificatie van) de bijbehorende
[Locatie(s)](#begrip-locaite).

*bron: TPOD*
