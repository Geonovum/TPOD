# Uitbreidbare waardelijst

Een **uitbreidbare waardelijst** is een [waardelijst](#begrip-waardelijst) met vooraf gedefinieerde waarden. 
Wanneer de gewenste waarde op de waardelijst voorkomt, wordt deze gebruikt. Als de gewenste waarde niet op de
waardelijst voorkomt, wordt door het bevoegd gezag een eigen waarde gedefinieerd. Deze waarde wordt overigens
niet aan de waardelijst toegevoegd.

*bron: TPOD*
