# Activiteitengroep

**Activiteitengroep** is de categorie waartoe de [activiteit](#begrip-activiteit) behoort. Voor activiteitengroep bestaat
een [limitatieve waardelijst](#begrip-limitatieve-waardelijst) 'Activiteitengroep'.

Iedere activiteitengroep heeft een eigen symboliek. Door te annoteren met een Activiteit met de eigenschap Activiteitengroep
kunnen de locaties van alle activiteiten in een (interactieve) viewer worden weergegeven op een kaart, zoals bijvoorbeeld in het DSO-LV.

*bron: TPOD*

