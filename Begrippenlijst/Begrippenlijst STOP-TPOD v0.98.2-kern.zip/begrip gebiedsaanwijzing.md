# Gebiedsaanwijzing

**Gebiedsaanwijzing** is een type [gebied](#begrip-gebied), aangewezen door een [Juridische regel](#begrip-juridische-regel) of een [Tekstdeel](#begrip-tekstdeel). 
Voorbeelden hiervan zijn Functie, Geluid en Ruimtelijk gebruik.

*bron: TPOD*
