# Geometrie

**Geometrie** is het object dat de geometrie bevat: de geometrische bepaling van een [Gebied](#begrip-gebied), [Lijn](#begrip-lijn) of [Punt](#begrip-punt) 
door middel van coördinaten.

*bron: TPOD*
