# Beperkingengebiedgroep

**Beperkingengebiedgroep** is de categorie waartoe de [beperkingengebied](#begrip-beperkingengebied) behoort.
Voor beperkingengebiedgroep bestaat een [limititatieve waardelijst](#begrip-limititatieve-waardelijst) 'Beperkingengebiedgroep'.

*bron: TPOD*

