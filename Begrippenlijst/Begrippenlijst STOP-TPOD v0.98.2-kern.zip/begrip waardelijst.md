# Waardelijst

Een **waardelijst** is een collectie van waarden die gebruikt kunnen worden bij het [annoteren](#begrip-annotatie-annoteren). 
Bij veel attributen van annotaties hoort een waardelijst met vooraf gedefinieerde waarden die het attribuut kan aannemen. Waardelijsten
zijn er in twee vormen: [limitatieve waardelijsten](#begrip-limitatieve-waardelijst) en [uitbreidbare waardelijsten](#begrip-uitbreidbare-waardelijst). 

*bron: STOP en TPOD*
