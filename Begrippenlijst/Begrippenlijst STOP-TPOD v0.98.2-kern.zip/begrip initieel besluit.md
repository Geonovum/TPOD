# Initieel besluit

Een **initieel besluit** is het eerste [besluit](#begrip-besluit) waarbij een volledig omgevingsdocument wordt vastgesteld. Het besluit dat leidt tot de eerste versie van de
[(geconsolideerde)](#begrip-consolideren) [regeling](#begrip-regeling).

*bron: STOP*
