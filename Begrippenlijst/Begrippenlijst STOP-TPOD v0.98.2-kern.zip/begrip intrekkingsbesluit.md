# Intrekkingsbesluit

Een **intrekkingsbesluit** is een [besluit](#begrip-besluit) waarin de intrekking van een [regeling](#begrip-regeling) geregeld wordt.

*bron: STOP*
