# Omgevingswaarde

Een **Omgevingswaarde** is een [norm](#begrip-norm) die voor (een onderdeel van) de fysieke leefomgeving de gewenste staat of kwaliteit, de toelaatbare
belasting door activiteiten en/of de toelaatbare concentratie of depositie van stoffen als beleidsdoel vastlegt. Omgevingswaarde wordt in een kwantitatieve
of kwalitatieve waarde  uitgedrukt.


*bron: TPOD*
