# Artikelstructuur

**Artikelstructuur** is de [tekststructuur](#begrip-tekststructuur) van het lichaam van een (formele) [regeling](#begrip-regeling) die is opgebouwd uit
één of meer artikelen.

*bron: STOP en TPOD

