# Muteren

**Muteren** is een ander woord voor wijzigen. In de terminologie van de
bekendmakingsregelgeving wordt daarmee bedoeld het aanbrengen van wijzigen in de
[regeling](#begrip-regeling).

*bron: STOP*
