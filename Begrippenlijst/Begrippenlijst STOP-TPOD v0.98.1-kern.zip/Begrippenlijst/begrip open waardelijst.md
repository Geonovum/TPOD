# Open waardelijst

Een **open waardelijst** is een [waardelijst](#begrip-waardelijst) met vooraf
gedefinieerde waarden. Wanneer de gewenste waarde op de waardelijst voorkomt,
wordt die gebruikt. Als de gewenste waarde niet op de waardelijst voorkomt,
wordt door het bevoegd gezag een eigen waarde gedefinieerd. Deze waarde wordt
niet aan de waardelijst toegevoegd.

*bron: TPOD*
