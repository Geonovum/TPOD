# Omgevingswaardegroep

**Omgevingswaardegroep** is de categorie waartoe de [Omgevingswaarde](#begrip-omgevingswaarde) behoort. 
Voor Omgevingswaardegroep bestaat een [gesloten waardelijst](#begrip-gesloten-waardelijst) 'Omgevingswaardegroep'. 

*bron: TPOD*
