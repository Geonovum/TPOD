# Structuurelementen

Ter ondersteuning van de weergave kent STOP een model waarin de (hiërarchische) structuur van de tekst beschreven is. De lopende tekst wordt daarin opgedeeld en beschreven met tekstblokken. De secties worden beschreven met behulp van **structuurelementen**, die de tekstblokken en eventuele structuurelementen van lagere niveaus bevatten. Zo ontstaat een hiërarchisch model van de tekst
Structuurelementen zijn die elementen die de tekst structureren maar geen inhoud bevatten; voorbeelden zijn Hoofdstuk en Paragraaf. 

*bron: STOP*
