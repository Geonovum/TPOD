# Service-informatie

**Service-informatie** is informatie die is afgeleid uit
[juridisch authentieke producten](#begrip-juridisch-authentiek-product) en waarvoor geen juridisch voorgeschreven
procedure bestaat om vast te stellen dat de inhoud juridisch correct is. Zie ook
[serviceproduct](#begrip-serviceproduct).

*bron: STOP*
