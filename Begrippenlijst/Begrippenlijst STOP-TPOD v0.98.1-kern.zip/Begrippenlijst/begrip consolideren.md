# Consolideren

**Consolideren** is het verwerken van de wijzigingen op een [initieel besluit](#begrip-initieel-besluit) na zijn inwerkingtreding, op basis van de wijzigingsinstructies die in
navolgende [besluiten](#begrip-besluit) zijn bekendgemaakt.

*bron: STOP*
