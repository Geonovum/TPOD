# Vrijetekststructuur

**Vrijetekststructuur** is de [tekststructuur](#begrip-tekststructuur) die wordt gebruikt voor juridisch authentieke documenten waarvan het lichaam van de [regeling](#begrip-regeling) geen artikelen bevat, zoals visiedocumenten en projectbesluiten.

*bron: STOP*
