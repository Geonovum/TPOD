# Locatie

**Locatie** legt vast wat het [werkingsgebied](#begrip-werkingsgebied) van een [Regeltekst](#begrip-regeltekst) of [Tekstdeel](#begrip-tekstdeel) is en geeft aan waar een [Juridische regel](#begrip-juridische-regel), Tekstdeel en inhoudelijke [annotaties](#begrip-annotatie-annoteren) van toepassing zijn.

*bron: TPOD*
