# Functiegroep

**Functiegroep** is de categorie waartoe de [functie](#begrip-functie) behoort. Voor
functiegroep bestaat een [gesloten waardelijst](#begrip-gesloten-waardelijst) 'Functiegroep'.

*bron: TPOD*
