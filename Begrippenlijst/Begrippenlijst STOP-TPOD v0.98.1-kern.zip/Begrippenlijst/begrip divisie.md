# Divisie

**Divisie** is het [structuurelement](#begrip-structuurelementen) dat gebruikt wordt voor de structurering van tekstonderdelen die niet tot het lichaam van de [regeling](#begrip-regeling) behoren, zoals motivering, toelichting of bijlagen.

*bron: STOP*
