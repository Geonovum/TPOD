# Tekstdeel

**Tekstdeel** is het object dat de relatie vormt tussen een beleids- of
realisatietekst en de daarmee samenhangende [annotaties](#begrip-annotatie-annoteren).

*bron: TPOD*
