# Regeltekst

Een **regeltekst** is de kleinste zelfstandige eenheid van (een of meer)
bij elkaar horende [Juridische regels](#begrip-juridische-regel) in (het lichaam van) een tekst met
[Artikelstructuur](#begrip-artikelstructuur), te weten een artikel of een lid.

*bron: STOP en TPOD*
