# Waardelijst

Een **waardelijst** is een collectie van waarden die gebruikt kunnen worden bij het [annoteren](#begrip-annotatie-annoteren). Bij veel attributen van annotaties hoort een waardelijst met vooraf gedefinieerde waarden die het attribuut kan aannemen. Waardelijsten zijn er in twee vormen: [gesloten waardelijsten](#begrip-gesloten-waardelijst) en [open waardelijsten](#begrip-open-waardelijst). 

*bron: STOP en TPOD*
