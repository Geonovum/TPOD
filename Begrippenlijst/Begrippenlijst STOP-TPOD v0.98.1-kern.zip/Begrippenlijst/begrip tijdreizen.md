# Tijdreizen

**Tijdreizen** is een mechanisme om vragen te stellen over hoe een
[regeling](#begrip-regeling) er uit zag (of wat de waarde van gegevens was) op een tijdstip in het
verleden (of in de toekomst).

*bron: STOP*
