# Inwerkingtredingsbesluit

Een **inwerkingstredingsbesluit** is een [besluit](#begrip-besluit) waarin de
inwerkingtreding van een of meer [regelingen](#begrip-regeling) wordt geregeld.

*bron: STOP*
