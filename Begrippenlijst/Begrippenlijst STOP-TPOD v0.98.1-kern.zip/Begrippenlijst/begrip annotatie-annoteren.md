# Annotatie / Annoteren

**Annoteren** is het toevoegen van gegevens aan (onderdelen van) [besluiten](#begrip-besluit) en
[regelingen](#begrip-regeling), gegevens die die besluiten en regelingen machineleesbaar maken. Dit
zorgt er voor dat het besluit of de regeling gestructureerd bevraagbaar is en
dat [werkingsgebieden](#begrip-werkingsgebied) en andere gegevens op een kaart weergegeven worden.

*bron: STOP en TPOD*

