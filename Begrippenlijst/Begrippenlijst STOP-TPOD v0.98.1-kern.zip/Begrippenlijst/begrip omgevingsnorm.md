# Omgevingsnorm

Een **omgevingsnorm** is een [norm](#begrip-norm) over de fysieke leefomgeving die in
een kwantitatieve of kwalitatieve waarde wordt uitgedrukt en geen
[omgevingswaarde](#begrip-omgevingswaarde) is.

*bron: TPOD*
