# Noemer

De **Noemer** is de mensleesbare naam waarmee een [informatieobject](#begrip-informatieobject) in een [besluit](#begrip-besluit) wordt aangeduid. De Noemer verbindt de tekst en het juridisch vastgestelde informatieobject op een manier waaruit een lezer kan begrijpen waar het informatieobject betrekking op heeft. De Noemer komt in tekstuele vorm voor in de lopende tekst van het Artikel, Lid of [Tekstdeel](#begrip-tekstdeel). Wanneer de Noemer gebruikt wordt om de tekst te verbinden met een [geografisch informatieobject](#begrip-geografisch-informatieobject), dan komt de Noemer ook voor in de [Juridische regel](#begrip-juridische-regel) respectievelijk het Tekstdeel en is het een attribuut van [Locatie](#begrip-locatie). Hierdoor is het duidelijk dat Locatie en Juridische regel respectievelijk Tekstdeel bij elkaar horen.

*bron: STOP en TPOD*
