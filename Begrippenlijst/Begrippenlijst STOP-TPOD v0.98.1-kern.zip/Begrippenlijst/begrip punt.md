# Punt

**Punt** is een op zichzelf staande geometrisch afgebakende puntlocatie in een virtuele weergave van de fysieke leefomgeving. Punt is één van de verschijningsvormen van [Locatie](#begrip-locatie).

*bron: TPOD*
