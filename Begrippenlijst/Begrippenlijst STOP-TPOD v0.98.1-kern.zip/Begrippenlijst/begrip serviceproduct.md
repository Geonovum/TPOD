# Serviceproduct

Een **serviceproduct** is een product waarvan de informatie is
afgeleid uit [juridisch authentieke producten](#begrip-juridisch-authentiek-product) en waarvoor geen juridisch
voorgeschreven procedure bestaat om vast te stellen dat de inhoud juridisch
correct is.

*bron: STOP*
