# Geografisch informatieobject

Een **geografisch informatieobject** is een [Informatieobject](#begrip-informatieobject) waarmee de [Locatie](#begrip-locatie) of Locaties die het [werkingsgebied](#begrip-werkingsgebied) van [Juridische regel](#begrip-juridische-regel) of [Tekstdeel](#begrip-tekstdeel) in omgevingsdocumenten worden vastgelegd.

*bron: STOP*
