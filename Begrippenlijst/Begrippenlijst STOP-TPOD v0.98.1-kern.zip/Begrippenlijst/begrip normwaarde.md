# Normwaarde

**Normwaarde** is het attribuut waarmee kan worden vastgelegd welke waarde een [omgevingsnorm](#begrip-omgevingsnorm) of [omgevingswaarde](#begrip-omgevingswaarde) op een bepaalde [Locatie](#begrip-locatie) heeft. Normwaarde kan kwantitatief (oftewel numeriek) of kwalitatief (oftewel in woorden) worden uitgedrukt. 

*bron: TPOD*
