# Gebiedengroep

**Gebiedengroep** is een groep of verzameling van bij elkaar behorende [Gebieden](#begrip-gebied), die samen de [Locatie](#begrip-locatie) vormen. Gebiedengroep is één van de verschijningsvormen van Locatie.

*bron TPOD*
