# Activiteit

**Activiteiten** zijn alle handelingen die de Omgevingswet reguleert.

Een activiteit betreft ieder menselijk handelen waarbij, of ieder menselijk
nalaten, waardoor een verandering of effect in de fysieke leefomgeving wordt of
kan worden bewerkstelligd.

Het is één van de [annotaties](#begrip-annotatie-annoteren) in DSO.

*bron: TPOD*

