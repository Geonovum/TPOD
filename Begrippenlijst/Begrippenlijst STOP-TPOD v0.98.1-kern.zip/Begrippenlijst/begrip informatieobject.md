# Informatieobject

Een **informatieobject** is een op zichzelf staand geheel van
gegevens, zoals een lijst, een register, een [geometrie](#begrip-geometrie) of een database. Het is
machineleesbare informatie die niet direct door mensen gelezen kan worden, maar
die met algemene beschikbare software te lezen is. In de tekst van het
[authentieke besluit](#begrip-authentiek-besluit) wordt een verwijzing opgenomen naar het informatieobject
waardoor de inhoud ervan onderdeel wordt van de beslissing. Het informatieobject
heeft een juridische status.

*bron: STOP*
