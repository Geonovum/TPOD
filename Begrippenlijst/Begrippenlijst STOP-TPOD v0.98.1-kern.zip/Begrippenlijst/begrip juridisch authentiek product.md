# Juridisch authentiek product

Een **juridisch authentiek product** is een product
waarvan de inhoud via een juridisch voorgeschreven procedure door een overheid
vastgesteld en gepubliceerd wordt.

*bron: STOP*
