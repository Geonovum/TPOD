# Artikelstructuur

**Artikelstructuur** is de [tekststructuur](#begrip-tekststructuur) waarbij het lichaam van een
(formele) [regeling](#begrip-regeling) is opgebouwd uit één of meer artikelen.

*bron: STOP*

