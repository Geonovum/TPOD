# Formele inhoud 

**FormeleInhoud** is het element met inhoud in het lichaam van instrumenten met een [Vrijetekststructuur](#begrip-vrijetekststructuur).

*bron: STOP*

