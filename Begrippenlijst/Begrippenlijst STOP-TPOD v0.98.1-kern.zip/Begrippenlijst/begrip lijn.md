# Lijn

**Lijn** is een op zichzelf staande geometrisch afgebakende lijnlocatie in een virtuele weergave van de fysieke leefomgeving. Lijn is één van de verschijningsvormen van [Locatie](#begrip-locatie).

*bron: TPOD*
