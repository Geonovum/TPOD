# Juridische regel

**Juridische regel** is een abstract concept dat een regel met juridische werkingskracht beschrijft.
Juridische regel wordt gebruikt om aan verschillende onderdelen van een [Regeltekst](#begrip-regeltekst) [Locaties](#begrip-locatie) en inhoudelijke [annotaties](#begrip-annotatie-annoteren) te kunnen koppelen.

*bron: TPOD*
