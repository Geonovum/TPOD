# Wijzigingsbesluit

Een **wijzigingsbesluit** is een [besluit](#begrip-besluit) waarin de wijziging van
een tekst of [regeling](#begrip-regeling) bekend wordt gemaakt.

*bron: STOP*
