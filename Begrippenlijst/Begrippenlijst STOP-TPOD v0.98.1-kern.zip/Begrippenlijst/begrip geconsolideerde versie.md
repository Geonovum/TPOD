# Geconsolideerde versie

Een **geconsolideerde versie** bevat de inhoud van een
[regeling](#begrip-regeling) zoals die geldt op een bepaald moment. De geconsolideerde versie wordt
afgeleid uit het [initiële besluit](#begrip-initieel-besluit) waarin steeds de (in werking getreden)
wijzigingen uit de [wijzigingsbesluiten](#begrip-wijzigingsbesluit) zijn verwerkt tot een doorlopende versie
van een type OW-besluit bv. Een doorlopende versie van het omgevingsplan.

In de terminologie van de bekendmakingsregelgeving wordt zo'n geconsolideerde
versie ook wel de regeling genoemd.

*bron: STOP*
