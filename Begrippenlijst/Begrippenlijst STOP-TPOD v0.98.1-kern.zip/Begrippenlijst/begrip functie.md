# Functie

Een **functie** is het gebruiksdoel of de bijzondere eigenschap die een
onderdeel van de fysieke leefomgeving op een bepaalde locatie heeft. Het is één
van de [annotaties](#begrip-annotatie-annoteren) in DSO.

*bron: TPOD*
