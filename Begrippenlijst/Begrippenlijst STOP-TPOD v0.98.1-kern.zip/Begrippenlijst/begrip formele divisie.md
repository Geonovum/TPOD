# Formele divisie 

**FormeleDivisie** is het [structuurelement](#begrip-structuurelementen) in het lichaam van instrumenten met een [Vrijetekststructuur](#begrip-vrijetekststructuur) dat de kleinste eenheid van (een of meer) bij elkaar horende beleidsteksten is waarnaar kan worden verwezen.

*bron: STOP*
