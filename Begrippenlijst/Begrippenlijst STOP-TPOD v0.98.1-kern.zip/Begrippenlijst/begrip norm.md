# Norm

Een **norm** is een [omgevingswaarde](#begrip-omgevingswaarde) of een [omgevingsnorm](#begrip-omgevingsnorm), met een normatief
karakter, die beschreven worden middels [normwaarden](#begrip-normwaarde). Een normwaarde kan
kwalitatief of kwantitatief zijn.

*bron: TPOD*
