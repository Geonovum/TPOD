# Werkingsgebied

Het **werkingsgebied** is een abstract, conceptueel begrip: het gebied waar een [Regeltekst](#begrip-regeltekst) of [FormeleDivisie](#begrip-formele-divisie) zijn werking heeft. 

*bron: STOP en TPOD*
