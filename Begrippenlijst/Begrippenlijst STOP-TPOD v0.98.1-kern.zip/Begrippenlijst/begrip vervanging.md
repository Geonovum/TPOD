# Vervanging

Een **vervanging** is een soort [mutatie](#begrip-muteren) dat leidt tot een wijziging van
een tekst of [regeling](#begrip-regeling). Het bestaat uit de specificatie van een geheel nieuwe
versie van de component waarbij de vorige versie komt te vervallen, ongeacht hoe
die vorige versie luidde.

*bron: STOP*
