# Gesloten waardelijst

Een **gesloten waardelijst** is een lijst met vooraf
gedefinieerde waarden waaruit gekozen moet worden. Deze [waardelijst](#begrip-waardelijst) wordt
centraal beheerd en kan alleen beheermatig per versie van de standaard gewijzigd
kan worden, omdat zij direct effect heeft op de werking van en functionaliteiten
van de applicaties van het DSO en LVBB.

*bron: TPOD*
