# Kenmerken

**Kenmerken** van [regeltekst](#begrip-regeltekst) geven aan voor welke onderwerpen een juridische
tekst relevant is zonder aan te geven wat er over in de tekst is vastgelegd.

*bron: STOP*
