# Raadpleegverzoek

Een **raadpleegverzoek** is een technische bevraging aan de
raadpleegservice van de LVBB. De raadpleegservice zendt via het
[bronhouderskoppelvlak](#begrip-bronhouderskoppelvlak) de gevraagde gegevens terug aan de bevragende partij,
uiteraard mits die partij bevoegd is de gegevens in te zien.

*bron: STOP*
