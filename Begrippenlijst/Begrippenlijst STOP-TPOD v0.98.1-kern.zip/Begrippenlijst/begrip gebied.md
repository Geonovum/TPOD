# Gebied

**Gebied** is een op zichzelf staande geometrisch afgebakende ‘ruimte’ in een virtuele weergave van de fysieke leefomgeving. Gebied is één van de verschijningsvormen van [Locatie](#begrip-locatie).

*bron: TPOD*
