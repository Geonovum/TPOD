# Omgevingsnormgroep

**Omgevingsnormgroep** is de categorie waartoe de [Omgevingsnorm](#begrip-omgevingsnorm) behoort. 
Voor Omgevingsnormgroep bestaat een [gesloten waardelijst](#begrip-gesloten-waardelijst) 'Omgevingsnormgroep'. 

*bron: TPOD*
