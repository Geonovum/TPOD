# Beperkingengebiedgroep

**Beperkingengebiedgroep** is de categorie waartoe de [beperkingengebied](#begrip-beperkingengebied) behoort.
Voor beperkingengebiedgroep bestaat een [gesloten waardelijst](#begrip-gesloten-waardelijst) 'Beperkingengebiedgroep'.

*bron: TPOD*

