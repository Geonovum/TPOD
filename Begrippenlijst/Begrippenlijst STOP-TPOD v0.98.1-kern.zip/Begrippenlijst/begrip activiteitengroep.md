# Activiteitengroep

**Activiteitengroep** is de categorie waartoe de [activiteit](#begrip-activiteit) behoort. Voor
activiteitengroep bestaat een [gesloten waardelijst](#begrip-gesloten-waardelijst) 'Activiteitengroep'.

*bron: TPOD*

