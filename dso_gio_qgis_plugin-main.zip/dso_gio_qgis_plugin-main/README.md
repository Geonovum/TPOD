GIO QGIS plugin
===============
Versie 1.1

QGIS plugin ontwikkeld op versie 3.18 om van een vectorlaag een GIO gml + xml te
maken.

Met de volgende mogelijkheden:

-   de features worden samengesmolten

-   de coordinaten worden afgerond, standaard op 3 decimalen

-   de geometrieën worden vereenvoudigd met Douglas-Peucker (afstand)

-   een selectie van de features in een laag

-   een selectie maken op basis van een attribuutwaarde

-   van elke waarde van een attribuut een GIO gml + xml maken

-   Meerdere GIO's maken op verschillende manieren
