Wijzigingen TPOD validatiebestanden 1.0.2
- Regeleindes validate.sh zijn nu LF (was CRLF)
- Validatie-regel 1750 is gerepareerd (handelde meerdere locaties in Activiteit niet goed af)
- Shebang regel gerepareerd- Vervangen begrip contents door sprekende tekst
- Validatie-regels 2010, 2020, 2030 zijn komen te vervallen
