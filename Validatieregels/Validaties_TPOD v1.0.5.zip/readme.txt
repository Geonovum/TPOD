Wijzigingen TPOD validatiebestanden 1.0.5
- Upgrade naar STOP 1.0.4
- Nieuwe structuur met schematron-templates en generieke uitvoer, geschikt voor JSON
- Validatie-regels 0830 en 0850 aangepast (was sprake van foutieve uitvoering)