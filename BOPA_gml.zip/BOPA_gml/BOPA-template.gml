<?xml version="1.0" encoding="UTF-8"?>
<FeatureCollectionGeometrie xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/basisgeometrie/1.0 https://register.geostandaarden.nl/gmlapplicatieschema/basisgeometrie/1.0.0/basisgeometrie.xsd" xmlns="http://www.geostandaarden.nl/basisgeometrie/1.0">
  <featureMember>
    <Geometrie>
      <id>6009ae06-d459-41d8-b21c-fccfb27d527f</id>
      <geometrie>
        <gml:MultiSurface gml:id="id-6009ae06-d459-41d8-b21c-fccfb27d527f-0" srsName="EPSG:28992">
          <gml:surfaceMember>
            <gml:Polygon gml:id="id-6009ae06-d459-41d8-b21c-fccfb27d527f-1">
              <gml:exterior>
                <gml:LinearRing>
                  <gml:posList>248252.359 575448.997 248244.134 575584.344 248279.516 575586.534 248288.277 575451.528 248252.359 575448.997</gml:posList>
                </gml:LinearRing>
              </gml:exterior>
              <gml:interior>
                <gml:LinearRing>
                  <gml:posList>248276.742 575583.371 248259.124 575582.105 248267.609 575453.438 248285.016 575454.74 248276.742 575583.371</gml:posList>
                </gml:LinearRing>
              </gml:interior>
            </gml:Polygon>
          </gml:surfaceMember>
          <gml:surfaceMember>
            <gml:Polygon gml:id="id-6009ae06-d459-41d8-b21c-fccfb27d527f-2">
              <gml:exterior>
                <gml:LinearRing>
                  <gml:posList>248268.47 575184.544 248253.854 575428.123 248290.634 575430.349 248305.303 575186.757 248268.47 575184.544</gml:posList>
                </gml:LinearRing>
              </gml:exterior>
              <gml:interior>
                <gml:LinearRing>
                  <gml:posList>248287.368 575427.157 248270.529 575426.086 248285.519 575188.78 248301.287 575189.85 248287.368 575427.157</gml:posList>
                </gml:LinearRing>
              </gml:interior>
            </gml:Polygon>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </geometrie>
    </Geometrie>
  </featureMember>
</FeatureCollectionGeometrie>