<?xml version="1.0" encoding="UTF-8"?>
<!--
================================================================================================
  Template-gml ten behoeve van BOPA-GML-bestanden. Zie voor de onderliggende xsd:
  https://register.geostandaarden.nl/gmlapplicatieschema/basisgeometrie/1.0.0/basisgeometrie.xsd
================================================================================================
-->
<FeatureCollectionGeometrie xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.geostandaarden.nl/basisgeometrie/1.0 https://register.geostandaarden.nl/gmlapplicatieschema/basisgeometrie/1.0.0/basisgeometrie.xsd" xmlns="http://www.geostandaarden.nl/basisgeometrie/1.0">
  <!--
  ==============================================================================================
    De FeatureCollectionGeometrie bestaat uit één of meer featureMembers.
    Plaats elke afzonderlijke gml:Polygon als featureMember.
  ==============================================================================================
  -->
  <featureMember>
    <!--
    ============================================================================================
      Elk feautureMember bevat één Geometrie.
    ============================================================================================
    -->
    <Geometrie>
      <!--
      ==========================================================================================
        Elke Geometrie bevat een id en geometrie.
        Voor het maken van een geldige GUID, zie bijvoorbeeld https://guidgenerator.com/.
        Het is mogelijk om hier een element complexType gml:AbstractFeatureType toe te voegen,
        bijvoorbeeld gml:naam en gml:boundedBy.
      ==========================================================================================
      -->
      <id>00000000-0000-0000-0000-000000000000</id>
      <geometrie>
        <!--
        ==========================================================================================
          Op het bovenliggende element in de gml-namespace zijn de attributen gml:id en 
          srsName="EPSG:28992" verplicht.
        ==========================================================================================
        -->
        <gml:MultiSurface gml:id="id-00000000-0000-0000-0000-000000000000-0" srsName="EPSG:28992">
          <gml:surfaceMember>
            <gml:Polygon gml:id="id-00000000-0000-0000-0000-000000000000-1">
              <gml:exterior>
                <gml:LinearRing>
                  <!--
                  ====================================================================================
                    Elke gml:posList bevat coördinaatparen (X Y) 'gesnapt' naar drie decimalen.
                  ====================================================================================
                  -->
                  <gml:posList></gml:posList>
                </gml:LinearRing>
              </gml:exterior>
            </gml:Polygon>
          </gml:surfaceMember>
          <!--
          ============================================================================================
            Wanneer de gml meerdere polygonen bevat, moet dit met een surfacemember worden toegevoegd.
          ============================================================================================
          -->
          <gml:surfaceMember>
            <gml:Polygon gml:id="id-00000000-0000-0000-0000-000000000000-2">
              <gml:exterior>
                <gml:LinearRing>
                  <gml:posList></gml:posList>
                </gml:LinearRing>
              </gml:exterior>
            </gml:Polygon>
          </gml:surfaceMember>
        </gml:MultiSurface>
      </geometrie>
    </Geometrie>
  </featureMember>
</FeatureCollectionGeometrie>