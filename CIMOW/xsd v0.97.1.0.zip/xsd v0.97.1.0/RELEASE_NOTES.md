# Release notes

Ten op zichte van de versie behorende bij VIMOW 0.9.7 van eind 2018, begin 2019. 

Versie: standaard 0.9.7.1.van 16 april 2019. 
Gebaseerd op: 
* CIMOW 0.9.7.1 van 16 april 2019. Functionele wijzigingen staan hierin opgesomd. Deze zorgen voor bijwerkingen van de 'OW' XSD's in de map /IMOW
- Generieke schema's voor het leveren van bestanden. 

## Namespace: 
https://www.geostandaarden.nl/imow/

## Versies
Alle schema's hebben versie 0_9_7 - deze volgen de x.y.z. systematiek. Dat deze specificatie gebaseerd is op STOP 0.9.7.1. is te zien aan de opgenomen
`<xs:appinfo>0.9.7.1</xs:appinfo>` 
  
 Opm. Referentie schemas krijgen versie 0_9 omdat er geen nieuwe objecttypen zijn bijgekomen. 

## Verbeteringen tusssen 0.9.7 en 0.9.7.1 
- Alle XSD's zijn gebaseerd op CIMOW. Dit leidt tot IMOW specifieke XSD's. 


